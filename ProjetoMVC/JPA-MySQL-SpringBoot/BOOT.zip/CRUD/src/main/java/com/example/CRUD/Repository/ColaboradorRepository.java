package com.example.CRUD.Repository;

import com.example.CRUD.Model.Colaborador;
import org.springframework.data.repository.CrudRepository;

public interface ColaboradorRepository extends CrudRepository<Colaborador, Integer> {

}
