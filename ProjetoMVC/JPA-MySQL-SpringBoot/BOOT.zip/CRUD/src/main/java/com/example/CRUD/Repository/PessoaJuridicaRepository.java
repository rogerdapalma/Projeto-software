package com.example.CRUD.Repository;

import com.example.CRUD.Model.PessoaJuridica;
import org.springframework.data.repository.CrudRepository;

public interface PessoaJuridicaRepository extends CrudRepository<PessoaJuridica, Integer> {

}
