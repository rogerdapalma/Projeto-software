package com.example.CRUD.Repository;

import com.example.CRUD.Model.Cliente;
import org.springframework.data.repository.CrudRepository;

public interface ClienteRepository extends CrudRepository<Cliente, Integer> {

}
