package com.example.CRUD.Repository;

import com.example.CRUD.Model.Projeto;
import org.springframework.data.repository.CrudRepository;

public interface ProjetoRepository extends CrudRepository<Projeto, Integer> {

}
