package com.example.CRUD.Repository;

import com.example.CRUD.Model.Alocacao;
import org.springframework.data.repository.CrudRepository;

public interface AlocacaoRepository extends CrudRepository<Alocacao, Integer> {

}
