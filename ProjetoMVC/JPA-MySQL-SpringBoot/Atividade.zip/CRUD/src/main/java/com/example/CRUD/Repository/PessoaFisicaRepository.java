package com.example.CRUD.Repository;

import com.example.CRUD.Model.PessoaFisica;
import org.springframework.data.repository.CrudRepository;

public interface PessoaFisicaRepository extends CrudRepository<PessoaFisica, Integer> {

}
